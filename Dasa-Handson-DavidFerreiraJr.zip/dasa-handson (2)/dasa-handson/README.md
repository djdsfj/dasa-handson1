**Como Executar o Projeto com Gradle**

**Linha de comando:** ./gradlew bootRun


**Como Executar os Testes Unitários**

**Linha de Comando:** ./gradlew test

**IDE's Recomendadas**

- Eclipse
- Intellij